var Joi = require('joi'),
  movieModle = require('../modle/movieDb').movieModle,
  fatch = require('node-fetch')


  // fatch data..
const omdbMovie = async (imdbId, callback) => {
let hostMovieData  = await fatch(`https://www.omdbapi.com/?apikey=7c1f340b&i=${imdbId}`)
let hostMovieJson = await hostMovieData.json();
  return hostMovieJson;
}

exports.getAll = {
  
  handler: async function (request, reply) {
          let imdbId = request.params.id
          console.log("id ",imdbId)
          try{
            movieModle.findById({imdbID:imdbId}, async function(err,existingUser){
              if (existingUser){
                  return existingUser
              }else{
                let movieData =  await omdbMovie(imdbId)
                let data = {
                  title : movieData['Title'],
                  year : movieData["Year"],
                  released : movieData["Released"],
                  genre : movieData["Genre"],
                  director : movieData["Director"],
                  awards : movieData["Awards"],
                  imdbID : movieData["imdbID"],
                  type : movieData["Type"],
                  ratings: movieData['Ratings']
                }
                movieData.save({data})
                return data
              } 
        })
      } catch(error) {
            return resp.response(error).code(500);
         }
          

          // let movieData =  omdbMovie(imdbId)
          // let data = {
          //   title : movieData['Title'],
          //   year : movieData["Year"],
          //   released : movieData["Released"],
          //   genre : movieData["Genre"],
          //   director : movieData["Director"],
          //   awards : movieData["Awards"],
          //   imdbID : movieData["imdbID"],
          //   type : movieData["Type"],
          //   ratings: movieData['Ratings']
          // }
          // return data
          }
      
}

          


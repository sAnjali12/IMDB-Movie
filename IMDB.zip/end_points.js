var User = require('./controller/movieData')
  	

// API Server Endpoints
exports.endpoints = [

  
  { method: 'GET', path: '/movie/{id}', config: User.getAll}
  
];
'use strict';

var mongoose = require('mongoose'),
    Schema = mongoose.Schema;


var UserSchema = new Schema({
    Title: String,
    Year: String,
    Released: String,
    Genre: String,
    Director:String,
    Awards: String,
    imdbID: String,
    Type: String,
    Ratings: String
  
});

var movieModle  = mongoose.model('movies', UserSchema);
module.exports = {
    movieModle
};




